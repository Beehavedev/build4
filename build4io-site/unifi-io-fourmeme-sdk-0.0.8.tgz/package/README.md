# FourMeme Node.js SDK

[![npm version](https://badge.fury.io/js/@unifi-io%2Ffourmeme-sdk.svg)](https://badge.fury.io/js/@unifi-io%2Ffourmeme-sdk)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Node.js Version](https://img.shields.io/badge/node-%3E%3D18-brightgreen)](https://nodejs.org/)

A comprehensive Node.js SDK for token swapping and creation on the BSC (Binance Smart Chain) network through the FourMeme platform. This SDK provides easy-to-use methods for interacting with FourMeme's token management system, including quote generation, token swapping, and meme token creation with support for multiple raised currencies.

## Features

- 🚀 **Token Swapping**: Get quotes and execute swaps between BNB and meme tokens
- 🎯 **Token Creation**: Create new meme tokens with custom parameters
- 🪙 **Multi-Currency Support**: Support for BNB, CAKE, USDT, USD1, and ASTER as raised currencies
- 🔐 **Authentication**: Built-in support for user authentication and signature handling
- 📊 **Token Information**: Retrieve detailed token information by ID
- 🛡️ **Type Safety**: Full TypeScript support with comprehensive type definitions
- ⚡ **Gas Optimization**: Automatic gas buffer management for native token transactions
- 🧪 **Testing**: Comprehensive test suite with Vitest
- 🔧 **Custom Fees**: Configurable buy and sell fees for token creation

## Installation

```bash
npm install @unifi-io/fourmeme-sdk
```

### Peer Dependencies

This SDK requires the following peer dependencies:

```bash
npm install ethers axios
```

## Quick Start

### Basic Setup

```typescript
import { FourMemeClient } from '@unifi-io/fourmeme-sdk'
import { ethers } from 'ethers'

// Initialize client
const provider = new ethers.JsonRpcProvider('https://bsc-dataseed.binance.org/')
const fourMemeClient = new FourMemeClient(provider)
```

### Getting a Quote

```typescript
const quoteParams = {
  fromToken: '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', // BNB (native token)
  toToken: '0x6b7f0da0bcb6f5757f94d227a03ddff1b24b4444', // Meme token address
  amount: '1.0',
  type: 'input' as const
}

const userAddress = '0xc0fa40699555a5692aacc69685583d0f5B0BA219'

try {
  const quote = await fourMemeClient.getQuote(quoteParams, userAddress)
  console.log('Quote:', quote)
} catch (error) {
  console.error('Failed to get quote:', error)
}
```

### Creating a Meme Token

```typescript
import { ethers } from 'ethers'

// Step 1: Get signature message
const signatureMessage = await fourMemeClient.buildSignatureMessage(userAddress)
console.log('Message to sign:', signatureMessage)

// Step 2: Sign the message with your private key
const wallet = new ethers.Wallet('YOUR_PRIVATE_KEY') // Replace with your private key
const signature = await wallet.signMessage(signatureMessage)

// Step 3: Get access token
const accessToken = await fourMemeClient.getAccessToken(signature, userAddress)

// Step 4: Create token
const tokenParams = {
  name: 'My Meme Token',
  symbol: 'MEME',
  description: 'A revolutionary meme token',
  totalSupply: 1000000000,
  raisedAmount: 18, // Updated amount for BNB
  saleRate: 0.8,
  amount: '0.1',
  raisedToken: 'BNB', // Choose from: BNB, CAKE, USDT, USD1, ASTER
  buyFee: 0.01, // 1% buy fee (optional)
  sellFee: 0.01 // 1% sell fee (optional)
}

const createResult = await fourMemeClient.buildCreateToken(
  tokenParams,
  userAddress,
  accessToken,
  signature
)

console.log('Token creation result:', createResult)
```

### Creating Token with Different Raised Currencies

```typescript
// Create token with CAKE as raised currency
const cakeTokenParams = {
  name: 'Cake Token',
  symbol: 'CAKE',
  description: 'A token raised with CAKE',
  raisedToken: 'CAKE',
  raisedAmount: 10000, // 10,000 CAKE
  // ... other parameters
}

// Create token with USDT as raised currency  
const usdtTokenParams = {
  name: 'USDT Token',
  symbol: 'USDT',
  description: 'A token raised with USDT',
  raisedToken: 'USDT',
  raisedAmount: 12000, // 12,000 USDT
  // ... other parameters
}

// Create token with ASTER as raised currency
const asterTokenParams = {
  name: 'Aster Token',
  symbol: 'ASTER',
  description: 'A token raised with ASTER',
  raisedToken: 'ASTER',
  raisedAmount: 5000, // 5,000 ASTER
  // ... other parameters
}
```

## API Reference

### FourMemeClient

The main class for interacting with the FourMeme platform.

#### Constructor

```typescript
constructor(provider: Provider)
```

- `provider`: Ethers.js provider instance

#### Methods

##### `getQuote(params: SwapParams, userAddress: string): Promise<SwapQuote>`

Get a quote for token swapping.

**Parameters:**
- `params`: Swap parameters including tokens, amount, and type
- `userAddress`: User's wallet address

**Returns:** Promise resolving to a SwapQuote object

##### `buildSignatureMessage(userAddress: string): Promise<string>`

Get the message that needs to be signed for authentication.

**Parameters:**
- `userAddress`: User's wallet address

**Returns:** Promise resolving to the signature message

##### `getAccessToken(signature: string, address: string): Promise<any>`

Get access token after signature verification.

**Parameters:**
- `signature`: Signed message
- `address`: User's wallet address

**Returns:** Promise resolving to access token data

##### `buildCreateToken(params: CreateTokenParams, userAddress: string, accessToken: string, signature: string): Promise<any>`

Create a new meme token.

**Parameters:**
- `params`: Token creation parameters
- `userAddress`: User's wallet address
- `accessToken`: Valid access token
- `signature`: Signed message

**Returns:** Promise resolving to token creation result

##### `getTokenInfoById(tokenId: number, accessToken: string): Promise<any>`

Get token information by ID.

**Parameters:**
- `tokenId`: Token ID
- `accessToken`: Valid access token

**Returns:** Promise resolving to token information

##### `adjustAmount(tokenAddress: string, amount: string, walletAddress: string): Promise<string>`

Adjust token amount based on user's balance and gas requirements.

**Parameters:**
- `tokenAddress`: Token contract address
- `amount`: Amount to adjust
- `walletAddress`: User's wallet address

**Returns:** Promise resolving to adjusted amount

##### `getTokenBalance(tokenAddress: string, walletAddress: string): Promise<{balance: bigint, formattedBalance: string}>`

Get token balance for a specific address.

**Parameters:**
- `tokenAddress`: Token contract address
- `walletAddress`: User's wallet address

**Returns:** Promise resolving to balance information

### Types

#### SwapParams

```typescript
interface SwapParams {
  fromToken: string
  toToken: string
  amount: string
  type: 'input' | 'output'
}
```

#### SwapQuote

```typescript
interface SwapQuote {
  quoteId: string
  fromToken: Token
  toToken: Token
  fromAmount: string
  toAmount: string
  priceImpact: number
  route: string[]
  estimatedGas: string
  type: 'input' | 'output'
  tx?: Transaction
  slippage: number
}
```

#### Token

```typescript
interface Token {
  address: `0x${string}`
  decimals: number
  symbol: string
}
```

#### CreateTokenParams

```typescript
interface CreateTokenParams {
  name: string
  symbol: string
  description: string
  img?: string
  totalSupply?: number
  raisedAmount?: number
  saleRate?: number
  amount?: string
  buyFee?: number // Buy fee rate (default: 0.01 = 1%)
  sellFee?: number // Sell fee rate (default: 0.01 = 1%)
  raisedToken?: 'BNB' | 'CAKE' | 'USDT' | 'USD1' | 'ASTER' // Raised token type
}
```

## Supported Networks

- **BSC (Binance Smart Chain)**: Primary supported network
- **Ethereum**: Limited support for token information

## Supported Raised Currencies

The SDK supports the following currencies for token creation:

| Currency | Symbol | Raised Amount | Contract Address |
|----------|--------|---------------|------------------|
| BNB | BNB | 18 BNB | `0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c` |
| CAKE | CAKE | 10,000 CAKE | `0x0e09fabb73bd3ade0a17ecc321fd13a19e81ce82` |
| USDT | USDT | 12,000 USDT | `0x55d398326f99059ff775485246999027b3197955` |
| USD1 | USD1 | 12,000 USD1 | `0x55d398326f99059ff775485246999027b3197955` |
| ASTER | ASTER | 5,000 ASTER | `0x55d398326f99059ff775485246999027b3197955` |

## Error Handling

The SDK provides comprehensive error handling for common scenarios:

- **Token not launched**: When trying to swap with unlaunched tokens
- **Insufficient balance**: When user doesn't have enough tokens
- **Network errors**: Connection and RPC errors
- **API errors**: FourMeme API related errors

```typescript
try {
  const quote = await fourMemeClient.getQuote(params, userAddress)
} catch (error) {
  if (error.message.includes('Token is not launched')) {
    console.error('Token is not available for trading')
  } else if (error.message.includes('insufficient balance')) {
    console.error('Insufficient token balance')
  } else {
    console.error('Unexpected error:', error)
  }
}
```

## Development

### Prerequisites

- Node.js >= 18
- npm or yarn

### Setup

```bash
# Clone the repository
git clone https://github.com/unifi-io/fourmeme-node-sdk.git
cd fourmeme-node-sdk

# Install dependencies
yarn install

# Build the project
yarn build
```

### Testing

```bash
# Run all tests
yarn test

# Run tests in watch mode
yarn test:watch

# Run tests with UI
yarn test:ui

# Run specific test
yarn test -t "should successfully create token with real signature"
```

### Scripts

- `yarn build`: Build the project
- `yarn dev`: Start development mode with watch
- `yarn test`: Run tests
- `yarn test:watch`: Run tests in watch mode
- `yarn test:ui`: Run tests with UI interface

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support and questions:

- 📧 Email: support@unifi.io
- 🐛 Issues: [GitHub Issues](https://github.com/unifi-io/fourmeme-node-sdk/issues)
- 📖 Documentation: [FourMeme Documentation](https://four.meme)

---

Made with ❤️ by the Unifi team