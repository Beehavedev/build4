import express from 'express'
import path from 'path'
import { db } from './db'
import { createBot } from './bot'
import { initRunner } from './agents/runner'

const app = express()
const PORT = parseInt(process.env.PORT ?? '3000')

app.use(express.json())

// Serve mini-app static files
const miniAppDist = path.join(__dirname, '..', 'miniapp', 'dist')
app.use('/app', express.static(miniAppDist))
app.get('/app/*', (_req, res) => {
  res.sendFile(path.join(miniAppDist, 'index.html'))
})

// REST API routes
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() })
})

app.get('/api/user/:telegramId', async (req, res) => {
  try {
    const user = await db.user.findUnique({
      where: { telegramId: BigInt(req.params.telegramId) },
      include: { wallets: true, portfolio: true }
    })
    if (!user) return res.status(404).json({ error: 'User not found' })
    res.json({ ...user, telegramId: user.telegramId.toString() })
  } catch (err) {
    res.status(500).json({ error: 'Internal error' })
  }
})

app.get('/api/agents/:userId', async (req, res) => {
  try {
    const agents = await db.agent.findMany({
      where: { userId: req.params.userId },
      orderBy: { createdAt: 'desc' }
    })
    res.json(agents)
  } catch {
    res.status(500).json({ error: 'Internal error' })
  }
})

app.post('/api/agents/:id/toggle', async (req, res) => {
  try {
    const agent = await db.agent.findUnique({ where: { id: req.params.id } })
    if (!agent) return res.status(404).json({ error: 'Agent not found' })

    const updated = await db.agent.update({
      where: { id: req.params.id },
      data: { isActive: !agent.isActive, isPaused: false }
    })
    res.json(updated)
  } catch {
    res.status(500).json({ error: 'Internal error' })
  }
})

app.get('/api/portfolio/:userId', async (req, res) => {
  try {
    const [portfolio, trades] = await Promise.all([
      db.portfolio.findUnique({ where: { userId: req.params.userId } }),
      db.trade.findMany({
        where: { userId: req.params.userId },
        orderBy: { openedAt: 'desc' },
        take: 50
      })
    ])
    res.json({ portfolio, trades })
  } catch {
    res.status(500).json({ error: 'Internal error' })
  }
})

app.get('/api/leaderboard', async (_req, res) => {
  try {
    const users = await db.user.findMany({
      include: {
        trades: {
          where: { status: 'closed' },
          select: { pnl: true, closedAt: true }
        }
      },
      take: 50
    })

    const ranked = users
      .map((u) => {
        const totalPnl = u.trades.reduce((s, t) => s + (t.pnl ?? 0), 0)
        const wins = u.trades.filter((t) => (t.pnl ?? 0) > 0).length
        const winRate = u.trades.length > 0 ? (wins / u.trades.length) * 100 : 0
        const thirtyDaysAgo = new Date(Date.now() - 30 * 86400000)
        const pnl30d = u.trades
          .filter((t) => t.closedAt && t.closedAt >= thirtyDaysAgo)
          .reduce((s, t) => s + (t.pnl ?? 0), 0)

        return {
          id: u.id,
          username: u.username ?? `User_${u.id.slice(0, 6)}`,
          totalTrades: u.trades.length,
          totalPnl,
          pnl30d,
          winRate
        }
      })
      .filter((u) => u.totalTrades > 0)
      .sort((a, b) => b.pnl30d - a.pnl30d)
      .slice(0, 10)

    res.json(ranked)
  } catch {
    res.status(500).json({ error: 'Internal error' })
  }
})

app.get('/api/signals', async (_req, res) => {
  const { getLatestSignals } = await import('./services/signals')
  const signals = await getLatestSignals(10)
  res.json(signals)
})

async function main() {
  // Connect DB
  await db.$connect()
  console.log('[DB] Connected')

  // Create bot
  const bot = createBot()

  // Webhook or polling
  const webhookUrl = process.env.TELEGRAM_WEBHOOK_URL

  if (webhookUrl) {
    // Webhook mode (production)
    app.post('/api/webhook', async (req, res) => {
      try {
        await bot.handleUpdate(req.body)
        res.sendStatus(200)
      } catch (err) {
        console.error('[Webhook] Error:', err)
        res.sendStatus(500)
      }
    })

    app.listen(PORT, async () => {
      console.log(`[Server] Running on port ${PORT}`)
      await bot.api.setWebhook(webhookUrl)
      console.log(`[Bot] Webhook set to ${webhookUrl}`)
    })
  } else {
    // Long polling mode (development)
    app.listen(PORT, () => {
      console.log(`[Server] Running on port ${PORT}`)
    })
    bot.start()
    console.log('[Bot] Started in polling mode')
  }

  // Start agent runner
  initRunner(bot)
  console.log('[Runner] Agent runner started')

  // Graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('[Server] Shutting down...')
    await bot.stop()
    await db.$disconnect()
    process.exit(0)
  })
}

main().catch((err) => {
  console.error('[Fatal]', err)
  process.exit(1)
})
